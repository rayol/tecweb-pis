"""
Per-sequence global-frame alignment for the IMUNet dataset.

Why this is needed
------------------
`ProposedSequence` rotates the IMU measurements into a global frame using

    init_rotor = init_tango_ori * game_rv[0].conj()
    ori        = init_rotor * game_rv

so the whole feature frame is fixed by a single sample, `ori_*[0]`, taken from the ground-truth
pose file. For the Lenovo Tango sequences that works: the resulting features are Z-up and match the
frame the `pos_*` columns live in. For the sequences recorded with the Android/ARCore pipeline
(S10, S21, Xiaomi) it does not — `read_data_s10.py` remaps the recorded position to
(x, -z, y) but leaves the pose quaternion in ARCore's own frame, so `init_rotor` ends up being a
wrong, constant rotation. Measured over the whole dataset, gravity in the feature frame is 0.1-1.8
degrees off +Z for all 49 Tango sequences and 34.9-115.6 degrees off for all 77 ARCore ones.

The consequence is that features and targets of the ARCore sequences sit in two frames that differ
by an arbitrary per-sequence rotation, including an arbitrary yaw. Yaw cannot be recovered by the
network (velocity regression from a global-frame window is yaw-equivariant, which is exactly what
the RandomHoriRotate augmentation relies on), so this is irreducible noise unless it is corrected.

What this module does
---------------------
Detection is ground-truth free: a sequence is flagged when gravity in its feature frame is more
than `tilt_thresh_deg` away from +Z. The correction itself is a calibration step that uses the
sequence's ground-truth positions: specific force in the global frame must satisfy

    R @ f_feature  ==  a_gt + (0, 0, g)

with `a_gt` the second derivative of the ground-truth position, so `R` is recovered in closed form
with Kabsch/SVD. Gravity pins the two tilt degrees of freedom, the walking accelerations pin yaw.

Zero-shot loss of the pre-trained RoNIN model on affected test sequences drops from ~0.55-0.81 to
~0.02-0.06, i.e. to the level the Tango sequences already had.
"""
import json
import os.path as osp

import numpy as np
from scipy.ndimage import uniform_filter1d

GRAVITY = 9.81
SMOOTH_WINDOW = 101  # 0.5 s at 200 Hz; longer windows wash out the accelerations that pin yaw


def gravity_tilt_deg(features):
    """Angle between mean specific force (i.e. gravity) in the feature frame and +Z, in degrees."""
    g = np.mean(features[:, 3:6], axis=0)
    g = g / np.linalg.norm(g)
    return float(np.degrees(np.arccos(np.clip(g[2], -1.0, 1.0))))


def estimate_alignment(ts, gt_pos, features, smooth_window=SMOOTH_WINDOW):
    """Rotation R such that `R @ f` maps the feature frame onto the ground-truth position frame."""
    ts = np.asarray(ts).reshape(-1)
    vel = np.gradient(uniform_filter1d(gt_pos, smooth_window, axis=0), ts, axis=0)
    acc = np.gradient(uniform_filter1d(vel, smooth_window, axis=0), ts, axis=0)
    acc = uniform_filter1d(acc, smooth_window, axis=0)

    force = uniform_filter1d(features[:, 3:6], smooth_window, axis=0)
    target = acc + np.array([0.0, 0.0, GRAVITY])

    valid = slice(smooth_window, len(ts) - smooth_window)
    u, _, vt = np.linalg.svd(force[valid].T @ target[valid])
    d = np.sign(np.linalg.det(vt.T @ u.T))
    return vt.T @ np.diag([1.0, 1.0, d]) @ u.T


def rotation_angle_deg(R):
    return float(np.degrees(np.arccos(np.clip((np.trace(R) - 1.0) / 2.0, -1.0, 1.0))))


def apply_rotation(features, R):
    """Rotate both the gyroscope and the accelerometer channels of an (N, 6) feature array."""
    return np.concatenate([features[:, 0:3] @ R.T, features[:, 3:6] @ R.T], axis=1)


class AlignmentCache:
    """Computes (and remembers) the per-sequence correction, keyed by sequence name."""

    def __init__(self, path=None, tilt_thresh_deg=20.0):
        self.path = path
        self.tilt_thresh_deg = tilt_thresh_deg
        self.entries = {}
        if path is not None and osp.exists(path):
            with open(path) as f:
                self.entries = json.load(f)

    def get(self, name, ts, gt_pos, features):
        """Return the rotation for `name`, or None when the sequence is already aligned."""
        if name not in self.entries:
            tilt = gravity_tilt_deg(features)
            if tilt <= self.tilt_thresh_deg:
                self.entries[name] = {'tilt_deg': tilt, 'aligned': False}
            else:
                R = estimate_alignment(ts, gt_pos, features)
                self.entries[name] = {'tilt_deg': tilt, 'aligned': True,
                                      'rotation_deg': rotation_angle_deg(R),
                                      'R': R.tolist()}
            self._save()
        entry = self.entries[name]
        return np.array(entry['R']) if entry['aligned'] else None

    def _save(self):
        if self.path is not None:
            with open(self.path, 'w') as f:
                json.dump(self.entries, f, indent=2)


def align_dataset(dataset, data_list, cache):
    """Rotate every sequence of a StridedSequenceDataset into its ground-truth position frame."""
    n_aligned = 0
    for i, name in enumerate(data_list):
        R = cache.get(name, dataset.ts[i], dataset.gt_pos[i], dataset.features[i])
        if R is not None:
            dataset.features[i] = apply_rotation(dataset.features[i], R)
            n_aligned += 1
    return n_aligned
