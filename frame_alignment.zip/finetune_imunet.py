"""
Fine-tuning of the pre-trained RoNIN ResNet18 model on the IMUNet dataset.

The pre-trained weights (models/ronin_resnet_model.pt) come from the RoNIN authors and were
trained on the RoNIN dataset with GlobSpeedSequence features (global-frame gyro + accelerometer,
window of 200 samples) and global 2D velocity as target. The IMUNet dataset is read with
ProposedSequence, which produces exactly the same feature/target layout, so the checkpoint can be
loaded as-is and only needs to be adapted to the new domain.

Herath, S., Yan, H. and Furukawa, Y., 2020, May. RoNIN: Robust Neural Inertial Navigation in the Wild:
Benchmark, Evaluations, & New Methods. In 2020 IEEE International Conference on Robotics and Automation
(ICRA) (pp. 3146-3152). IEEE.
"""
import argparse
import json
import math
import os
import os.path as osp
import random
import time

import matplotlib

matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import torch
from scipy.interpolate import interp1d
from torch.utils.data import DataLoader

from frame_alignment import AlignmentCache, align_dataset
from metric import compute_ate_rte
from model_resnet1d import ResNet1D, BasicBlock1D, FCOutputModule
from utils import ProposedSequence, StridedSequenceDataset, RandomHoriRotate

_fc_config = {'fc_dim': 512, 'in_dim': 7, 'dropout': 0.5, 'trans_planes': 128}
_input_channel, _output_channel = 6, 2


def build_network(window_size):
    fc_config = dict(_fc_config)
    fc_config['in_dim'] = window_size // 32 + 1
    return ResNet1D(_input_channel, _output_channel, BasicBlock1D, [2, 2, 2, 2],
                    base_plane=64, output_block=FCOutputModule, kernel_size=3, **fc_config)


def load_pretrained(network, path):
    """Load the RoNIN checkpoint, reporting any layer that does not transfer."""
    checkpoint = torch.load(path, map_location='cpu', weights_only=False)
    state_dict = checkpoint.get('model_state_dict', checkpoint)
    missing, unexpected = network.load_state_dict(state_dict, strict=False)
    print('Loaded pre-trained weights from {} (epoch {})'.format(path, checkpoint.get('epoch', '?')))
    if missing:
        print('  Randomly initialized (not in checkpoint): {}'.format(missing))
    if unexpected:
        print('  Ignored (not in model): {}'.format(unexpected))
    return network


def freeze_stages(network, n_stages):
    """Freeze the first n_stages blocks: 1 = stem, 2..5 = stem + first 1..4 residual groups."""
    if n_stages <= 0:
        return
    blocks = [network.input_block] + list(network.residual_groups)
    for block in blocks[:min(n_stages, len(blocks))]:
        for param in block.parameters():
            param.requires_grad = False
    trainable = sum(p.numel() for p in network.parameters() if p.requires_grad)
    total = sum(p.numel() for p in network.parameters())
    print('Froze {} stage(s): {}/{} parameters trainable'.format(n_stages, trainable, total))


def set_frozen_bn_eval(network, n_stages):
    """Keep BatchNorm running statistics of frozen stages fixed while training."""
    if n_stages <= 0:
        return
    blocks = [network.input_block] + list(network.residual_groups)
    for block in blocks[:min(n_stages, len(blocks))]:
        for module in block.modules():
            if isinstance(module, torch.nn.BatchNorm1d):
                module.eval()


def read_list(path):
    with open(path) as f:
        return [s.strip().split(',')[0] for s in f.readlines() if len(s.strip()) > 0 and s[0] != '#']


def split_train_val(data_list, val_ratio, seed):
    """Hold out whole sequences for validation, spread evenly over subject/device groups.

    Sequences are named <Environment>_<Subject>_<Device>_<index>; everything but the trailing index
    forms a group, so the validation set covers every subject/device combination present in training.

    A dataset whose names do not follow that convention puts every sequence in a group of its own,
    and the "keep at least one member in training" rule then empties the validation set entirely.
    That is not a harmless degradation: without a validation loader the training loop never writes
    checkpoint_best.pt, never steps the LR scheduler and never early-stops. So when the grouped
    split yields nothing, fall back to an ungrouped random split over whole sequences. Datasets
    that do follow the convention are unaffected, and the fallback is still deterministic in seed.
    """
    if val_ratio <= 0 or len(data_list) < 2:
        return data_list, []
    groups = {}
    for name in data_list:
        groups.setdefault(name.rsplit('_', 1)[0], []).append(name)

    rng = random.Random(seed)
    val = []
    for key in sorted(groups):
        members = sorted(groups[key])
        rng.shuffle(members)
        n_val = min(len(members) - 1, max(1, int(round(len(members) * val_ratio))))
        val.extend(members[:n_val])

    if not val:
        members = sorted(data_list)
        rng.shuffle(members)
        n_val = min(len(members) - 1, max(1, int(round(len(members) * val_ratio))))
        val = members[:n_val]
        print('Sequence names give no usable subject/device groups ({} group(s) for {} sequences); '
              'falling back to an ungrouped random validation split.'.format(len(groups), len(data_list)))

    val_set = set(val)
    train = [name for name in data_list if name not in val_set]
    return train, sorted(val)


def get_dataset(root_dir, data_list, args, mode):
    random_shift, shuffle, transforms, grv_only = 0, False, None, False
    if mode == 'train':
        random_shift = args.step_size // 2
        shuffle = True
        transforms = RandomHoriRotate(math.pi * 2)
    elif mode == 'val':
        shuffle = True
    elif mode == 'test':
        shuffle = False
        grv_only = True

    dataset = StridedSequenceDataset(
        ProposedSequence, root_dir, data_list, args.cache_path, args.step_size, args.window_size,
        random_shift=random_shift, transform=transforms,
        shuffle=shuffle, grv_only=grv_only, max_ori_error=args.max_ori_error)

    if args.align_frame:
        n = align_dataset(dataset, data_list, _alignment_cache(args))
        if n:
            print('Frame alignment applied to {}/{} sequences'.format(n, len(data_list)))
    return dataset


_ALIGNMENT_CACHE = None


def _alignment_cache(args):
    global _ALIGNMENT_CACHE
    if _ALIGNMENT_CACHE is None:
        _ALIGNMENT_CACHE = AlignmentCache(osp.join(args.root_dir, 'frame_alignment.json'),
                                          tilt_thresh_deg=args.align_tilt_deg)
    return _ALIGNMENT_CACHE


def run_inference(network, data_loader, device):
    network.eval()
    targets_all, preds_all = [], []
    with torch.no_grad():
        for feat, targ, _, _ in data_loader:
            pred = network(feat.to(device)).cpu().numpy()
            targets_all.append(targ.numpy())
            preds_all.append(pred)
    return np.concatenate(targets_all, axis=0), np.concatenate(preds_all, axis=0)


def recon_traj_with_preds(dataset, preds, seq_id=0):
    """Reconstruct the trajectory by integrating the predicted global velocities."""
    ts = dataset.ts[seq_id]
    ind = np.array([i[1] for i in dataset.index_map if i[0] == seq_id], dtype=np.int64)
    dts = np.mean(ts[ind[1:]] - ts[ind[:-1]])
    pos = np.zeros([preds.shape[0] + 2, 2])
    pos[0] = dataset.gt_pos[seq_id][0, :2]
    pos[1:-1] = np.cumsum(preds[:, :2] * dts, axis=0) + pos[0]
    pos[-1] = pos[-2]
    ts_ext = np.concatenate([[ts[0] - 1e-06], ts[ind], [ts[-1] + 1e-06]], axis=0)
    return interp1d(ts_ext, pos, axis=0)(ts)


def evaluate(network, args, data_list, device, out_dir=None, save_plots=False, tag='test'):
    """Per-sequence MSE / ATE / RTE over full sequences."""
    pred_per_min = 200 * 60
    losses_seq, ate_all, rte_all = [], [], []

    for name in data_list:
        seq_dataset = get_dataset(args.root_dir, [name], args, mode='test')
        seq_loader = DataLoader(seq_dataset, batch_size=1024, shuffle=False)
        targets, preds = run_inference(network, seq_loader, device)

        losses = np.mean((targets - preds) ** 2, axis=0)
        pos_pred = recon_traj_with_preds(seq_dataset, preds)[:, :2]
        pos_gt = seq_dataset.gt_pos[0][:, :2]
        ate, rte = compute_ate_rte(pos_pred, pos_gt, pred_per_min)

        losses_seq.append(losses)
        ate_all.append(ate)
        rte_all.append(rte)
        print('  {}: loss {:.6f}, ate {:.3f}, rte {:.3f}'.format(name, np.mean(losses), ate, rte))

        if save_plots and out_dir is not None:
            plt.figure(figsize=(6, 6))
            plt.plot(pos_pred[:, 0], pos_pred[:, 1], label='Predicted')
            plt.plot(pos_gt[:, 0], pos_gt[:, 1], label='Ground truth')
            plt.axis('equal')
            plt.legend()
            plt.title('{} — ATE {:.3f}, RTE {:.3f}'.format(name, ate, rte))
            plt.tight_layout()
            plt.savefig(osp.join(out_dir, name + '_traj.png'), dpi=100)
            plt.close('all')

    losses_seq = np.stack(losses_seq, axis=0)
    summary = {'loss': float(np.mean(losses_seq)),
               'ate': float(np.mean(ate_all)), 'rte': float(np.mean(rte_all))}
    print('[{}] avg loss {:.6f}, avg ATE {:.3f} m, avg RTE {:.3f} m'.format(
        tag, summary['loss'], summary['ate'], summary['rte']))

    if out_dir is not None:
        os.makedirs(out_dir, exist_ok=True)
        with open(osp.join(out_dir, 'metrics_{}.csv'.format(tag)), 'w') as f:
            f.write('seq,vx,vy,avg,ate,rte\n')
            for i, name in enumerate(data_list):
                f.write('{},{:.6f},{:.6f},{:.6f},{:.6f},{:.6f}\n'.format(
                    name, losses_seq[i][0], losses_seq[i][1], np.mean(losses_seq[i]),
                    ate_all[i], rte_all[i]))
            f.write('AVERAGE,{:.6f},{:.6f},{:.6f},{:.6f},{:.6f}\n'.format(
                np.mean(losses_seq[:, 0]), np.mean(losses_seq[:, 1]),
                summary['loss'], summary['ate'], summary['rte']))
    return summary


def train(args, device):
    train_list = read_list(args.train_list)
    if args.val_list:
        val_list = read_list(args.val_list)
    else:
        train_list, val_list = split_train_val(train_list, args.val_ratio, args.seed)
    print('{} training sequences, {} validation sequences'.format(len(train_list), len(val_list)))
    print('Validation sequences: {}'.format(val_list))

    start_t = time.time()
    train_dataset = get_dataset(args.root_dir, train_list, args, mode='train')
    train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True,
                              num_workers=args.workers, drop_last=True)
    val_loader = None
    if val_list:
        val_dataset = get_dataset(args.root_dir, val_list, args, mode='val')
        val_loader = DataLoader(val_dataset, batch_size=512, shuffle=False, num_workers=args.workers)
        print('Number of val windows: {}'.format(len(val_dataset)))
    print('Data loaded in {:.1f}s. Number of train windows: {}'.format(
        time.time() - start_t, len(train_dataset)))

    ckpt_dir = osp.join(args.out_dir, 'checkpoints')
    os.makedirs(ckpt_dir, exist_ok=True)
    with open(osp.join(args.out_dir, 'config.json'), 'w') as f:
        json.dump({**vars(args), 'train_list_resolved': train_list, 'val_list_resolved': val_list},
                  f, indent=2)

    network = build_network(args.window_size)
    if args.pretrained:
        load_pretrained(network, args.pretrained)
    freeze_stages(network, args.freeze_stages)
    network = network.to(device)

    criterion = torch.nn.MSELoss()
    params = [p for p in network.parameters() if p.requires_grad]
    optimizer = torch.optim.Adam(params, args.lr)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, factor=0.1, patience=args.lr_patience, eps=1e-12)

    if val_loader is not None:
        init_targ, init_pred = run_inference(network, val_loader, device)
        best_val_loss = float(np.mean((init_targ - init_pred) ** 2))
        print('Initial validation loss ({}): {:.6f}'.format(
            'pre-trained, before fine-tuning' if args.pretrained else 'random init', best_val_loss))
    else:
        # Nothing below writes checkpoint_best.pt, steps the scheduler or early-stops in this case.
        print('WARNING: no validation sequences. checkpoint_best.pt will not be written, the LR '
              'scheduler will never step and early stopping is disabled; training will run the '
              'full {} epochs and you will be left with checkpoint_latest.pt.'.format(args.epochs))
        best_val_loss = np.inf

    history, epochs_without_improvement = [], 0
    try:
        for epoch in range(args.epochs):
            start_t = time.time()
            network.train()
            set_frozen_bn_eval(network, args.freeze_stages)
            running_loss, n_batches = 0.0, 0
            for feat, targ, _, _ in train_loader:
                feat, targ = feat.to(device), targ.to(device)
                optimizer.zero_grad()
                loss = criterion(network(feat), targ)
                loss.backward()
                optimizer.step()
                running_loss += loss.item()
                n_batches += 1
            train_loss = running_loss / max(n_batches, 1)

            line = 'Epoch {:3d}/{}  {:.1f}s  train loss {:.6f}'.format(
                epoch + 1, args.epochs, time.time() - start_t, train_loss)
            val_loss = None
            if val_loader is not None:
                val_targ, val_pred = run_inference(network, val_loader, device)
                val_loss = float(np.mean((val_targ - val_pred) ** 2))
                scheduler.step(val_loss)
                line += '  val loss {:.6f}  lr {:.2e}'.format(val_loss, optimizer.param_groups[0]['lr'])
                if val_loss < best_val_loss:
                    best_val_loss = val_loss
                    epochs_without_improvement = 0
                    torch.save({'model_state_dict': network.state_dict(),
                                'optimizer_state_dict': optimizer.state_dict(),
                                'epoch': epoch}, osp.join(ckpt_dir, 'checkpoint_best.pt'))
                    line += '  *best*'
                else:
                    epochs_without_improvement += 1
            print(line)
            history.append({'epoch': epoch, 'train_loss': train_loss, 'val_loss': val_loss})

            torch.save({'model_state_dict': network.state_dict(),
                        'optimizer_state_dict': optimizer.state_dict(),
                        'epoch': epoch}, osp.join(ckpt_dir, 'checkpoint_latest.pt'))

            if args.early_stop > 0 and epochs_without_improvement >= args.early_stop:
                print('No validation improvement for {} epochs, stopping early.'.format(args.early_stop))
                break
    except KeyboardInterrupt:
        print('Early terminate')

    with open(osp.join(args.out_dir, 'history.json'), 'w') as f:
        json.dump(history, f, indent=2)
    print('Training complete. Best validation loss: {:.6f}'.format(best_val_loss))

    best_path = osp.join(ckpt_dir, 'checkpoint_best.pt')
    if osp.exists(best_path):
        network.load_state_dict(torch.load(best_path, map_location=device,
                                           weights_only=False)['model_state_dict'])
    print('\nEvaluating the fine-tuned model on the test set:')
    evaluate(network, args, read_list(args.test_list), device,
             out_dir=args.out_dir, save_plots=args.save_plots, tag='test')


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    repo_root = osp.dirname(osp.dirname(osp.abspath(__file__)))
    parser.add_argument('--mode', type=str, default='train', choices=['train', 'eval'],
                        help='"eval" only runs the test-set evaluation of --model_path')
    parser.add_argument('--root_dir', type=str, default=osp.join(repo_root, 'Datasets/IMUNet_dataset'))
    parser.add_argument('--train_list', type=str, default=None)
    parser.add_argument('--val_list', type=str, default=None,
                        help='If omitted, a validation split is carved out of --train_list')
    parser.add_argument('--test_list', type=str, default=None)
    parser.add_argument('--val_ratio', type=float, default=0.12)
    parser.add_argument('--pretrained', type=str, default=osp.join(repo_root, 'models/ronin_resnet_model.pt'),
                        help='RoNIN checkpoint to start from; pass "" to train from scratch')
    parser.add_argument('--model_path', type=str, default=None, help='Checkpoint to evaluate in eval mode')
    parser.add_argument('--out_dir', type=str,
                        default=osp.join(repo_root, 'RONIN_torch/Train_out/ResNet/imunet_finetune'))
    parser.add_argument('--cache_path', type=str, default=None)
    parser.add_argument('--freeze_stages', type=int, default=0,
                        help='0 = fine-tune everything, 1 = freeze the stem, 2..5 = stem + first 1..4 residual groups')
    parser.add_argument('--lr', type=float, default=1e-4)
    parser.add_argument('--lr_patience', type=int, default=5)
    parser.add_argument('--batch_size', type=int, default=128)
    parser.add_argument('--epochs', type=int, default=50)
    parser.add_argument('--early_stop', type=int, default=12, help='0 disables early stopping')
    parser.add_argument('--step_size', type=int, default=10)
    parser.add_argument('--window_size', type=int, default=200)
    parser.add_argument('--max_ori_error', type=float, default=20.0)
    parser.add_argument('--no_align_frame', dest='align_frame', action='store_false',
                        help='Disable the per-sequence global-frame correction (see frame_alignment.py)')
    parser.add_argument('--align_tilt_deg', type=float, default=20.0,
                        help='A sequence is corrected when its gravity is more than this far from +Z')
    parser.add_argument('--workers', type=int, default=0)
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--cpu', action='store_true')
    parser.add_argument('--save_plots', action='store_true', help='Write per-sequence trajectory plots')
    args = parser.parse_args()

    if args.train_list is None:
        args.train_list = osp.join(args.root_dir, 'list_train.txt')
    if args.test_list is None:
        args.test_list = osp.join(args.root_dir, 'list_test.txt')

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    np.set_printoptions(formatter={'all': lambda x: '{:.6f}'.format(x)})

    device = torch.device('cuda:0' if torch.cuda.is_available() and not args.cpu else 'cpu')
    print('Using device: {}'.format(device))
    os.makedirs(args.out_dir, exist_ok=True)

    if args.mode == 'train':
        train(args, device)
    else:
        network = build_network(args.window_size).to(device)
        model_path = args.model_path or args.pretrained
        load_pretrained(network, model_path)
        evaluate(network, args, read_list(args.test_list), device, out_dir=args.out_dir,
                 save_plots=args.save_plots, tag=osp.splitext(osp.basename(model_path))[0])


if __name__ == '__main__':
    main()
