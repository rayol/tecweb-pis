"""
Train the RoNIN ResNet18 (ResNet1D) from scratch on the IMUNet ("proposed") dataset.

This is the training half of main.py, extracted so it can actually run: main.py imports
CNN_LSTM and IMUNet_1_Pytorch, which are not part of this repository, and it hardcodes
Datasets/proposed as the data root while the sequences live in Datasets/IMUNet_dataset.

Everything else follows the repository: sequences are read by ProposedSequence (global-frame
gyroscope + accelerometer, target = average 2D velocity over the window), windows are cut by
StridedSequenceDataset, the loss is MSE on the 2D velocity and the optimiser is Adam with
ReduceLROnPlateau.

No pre-trained weights are used -- the network starts from a random initialisation, so the
frame alignment needed when reusing RoNIN's weights does not apply here: whatever convention
the IMUNet sequences use is what the network learns.

The list_test.txt sequences are held out for the final evaluation; the validation split is
carved out of list_train.txt at whole-sequence granularity so no window leaks between splits.

Usage (from the directory holding this file):
    python train_proposed.py
    python train_proposed.py --epochs 60 --lr 1e-4
"""
import argparse
import json
import math
import os
import os.path as osp
import random
import time

import numpy as np
import torch
from scipy.interpolate import interp1d
from torch.utils.data import DataLoader

from metric import compute_ate_rte
from model_resnet1d import ResNet1D, BasicBlock1D, FCOutputModule
from utils import ProposedSequence, StridedSequenceDataset, RandomHoriRotate

# Kept identical to main.py (and to export_pte.py, which has to rebuild the same graph).
_fc_config = {'fc_dim': 512, 'in_dim': 7, 'dropout': 0.5, 'trans_planes': 128}
_input_channel, _output_channel = 6, 2

_REPO_ROOT = osp.dirname(osp.dirname(osp.abspath(__file__)))
_SAMPLING_RATE = 200  # Hz, used to size the RTE window (one minute of predictions).


def build_network(window_size):
    fc_config = dict(_fc_config)
    fc_config['in_dim'] = window_size // 32 + 1
    return ResNet1D(_input_channel, _output_channel, BasicBlock1D, [2, 2, 2, 2],
                    base_plane=64, output_block=FCOutputModule, kernel_size=3, **fc_config)


def read_list(path):
    with open(path) as f:
        return [s.strip().split(',')[0] for s in f if len(s.strip()) > 0 and s[0] != '#']


def split_train_val(sequences, val_ratio, seed):
    """Hold out whole sequences for validation, keeping the split reproducible."""
    shuffled = list(sequences)
    random.Random(seed).shuffle(shuffled)
    n_val = max(1, int(round(len(shuffled) * val_ratio)))
    val = sorted(shuffled[:n_val])
    train = sorted(shuffled[n_val:])
    return train, val


def make_dataset(root_dir, data_list, args, mode):
    random_shift, shuffle, transform = 0, False, None
    if mode == 'train':
        random_shift, shuffle = args.step_size // 2, True
        transform = RandomHoriRotate(math.pi * 2)
    elif mode == 'val':
        shuffle = True

    return StridedSequenceDataset(
        ProposedSequence, root_dir, data_list, args.cache_path, args.step_size, args.window_size,
        random_shift=random_shift, transform=transform, shuffle=shuffle, grv_only=False,
        max_ori_error=args.max_ori_error)


def run_inference(network, loader, device):
    network.eval()
    targets_all, preds_all = [], []
    with torch.no_grad():
        for feat, targ, _, _ in loader:
            preds_all.append(network(feat.to(device)).cpu().numpy())
            targets_all.append(targ.numpy())
    return np.concatenate(targets_all, axis=0), np.concatenate(preds_all, axis=0)


def recon_traj_with_preds(dataset, preds, seq_id=0):
    """Reconstruct the trajectory by integrating the predicted global velocities."""
    ts = dataset.ts[seq_id]
    ind = np.array([i[1] for i in dataset.index_map if i[0] == seq_id], dtype=np.int64)
    dts = np.mean(ts[ind[1:]] - ts[ind[:-1]])
    pos = np.zeros([preds.shape[0] + 2, 2])
    pos[0] = dataset.gt_pos[seq_id][0, :2]
    pos[1:-1] = np.cumsum(preds[:, :2] * dts, axis=0) + pos[0]
    pos[-1] = pos[-2]
    ts_ext = np.concatenate([[ts[0] - 1e-06], ts[ind], [ts[-1] + 1e-06]], axis=0)
    return interp1d(ts_ext, pos, axis=0)(ts)


def evaluate(network, args, test_list, device):
    """Per-sequence velocity MSE plus ATE/RTE of the integrated trajectory."""
    rows = []
    for seq in test_list:
        dataset = make_dataset(args.root_dir, [seq], args, mode='test')
        loader = DataLoader(dataset, batch_size=1024, shuffle=False)
        targets, preds = run_inference(network, loader, device)

        losses = np.mean((targets - preds) ** 2, axis=0)
        pos_pred = recon_traj_with_preds(dataset, preds)[:, :2]
        pos_gt = dataset.gt_pos[0][:, :2]
        ate, rte = compute_ate_rte(pos_pred, pos_gt, _SAMPLING_RATE * 60)

        rows.append((seq, losses[0], losses[1], np.mean(losses), ate, rte))
        print('  {}: loss {:.6f}, ate {:.3f}, rte {:.3f}'.format(seq, np.mean(losses), ate, rte),
              flush=True)

    averages = np.mean([r[1:] for r in rows], axis=0)
    if args.out_dir:
        with open(osp.join(args.out_dir, 'metrics_test.csv'), 'w') as f:
            f.write('seq,vx,vy,avg,ate,rte\n')
            for seq, vx, vy, avg, ate, rte in rows:
                f.write('{},{:.6f},{:.6f},{:.6f},{:.6f},{:.6f}\n'.format(seq, vx, vy, avg, ate, rte))
            f.write('AVERAGE,{:.6f},{:.6f},{:.6f},{:.6f},{:.6f}\n'.format(*averages))
    print('[test] avg loss {:.6f}, avg ATE {:.3f} m, avg RTE {:.3f} m'.format(
        averages[2], averages[3], averages[4]), flush=True)
    return averages


def write_config(args, train_list, val_list, test_list):
    config = dict(vars(args))
    config.update({'train_list_resolved': train_list,
                   'val_list_resolved': val_list,
                   'test_list_resolved': test_list})
    with open(osp.join(args.out_dir, 'config.json'), 'w') as f:
        json.dump(config, f, indent=2)


def train(args):
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    random.seed(args.seed)

    device = torch.device('cuda:0' if torch.cuda.is_available() and not args.cpu else 'cpu')
    print('Using device: {}'.format(device))

    all_train = read_list(args.train_list)
    test_list = read_list(args.test_list)
    train_list, val_list = split_train_val(all_train, args.val_ratio, args.seed)
    print('{} training sequences, {} validation sequences, {} test sequences'.format(
        len(train_list), len(val_list), len(test_list)))
    print('Validation sequences: {}'.format(val_list))

    os.makedirs(osp.join(args.out_dir, 'checkpoints'), exist_ok=True)
    write_config(args, train_list, val_list, test_list)

    start_t = time.time()
    train_dataset = make_dataset(args.root_dir, train_list, args, mode='train')
    val_dataset = make_dataset(args.root_dir, val_list, args, mode='val')
    train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True,
                              num_workers=args.workers, drop_last=True)
    val_loader = DataLoader(val_dataset, batch_size=512, shuffle=False, num_workers=args.workers)
    print('Data loaded in {:.1f}s. Train windows: {}, val windows: {}'.format(
        time.time() - start_t, len(train_dataset), len(val_dataset)), flush=True)

    network = build_network(args.window_size).to(device)
    print('Network: {} parameters'.format(sum(p.numel() for p in network.parameters())))

    criterion = torch.nn.MSELoss()
    optimizer = torch.optim.Adam(network.parameters(), args.lr)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, factor=0.1, patience=args.lr_patience, eps=1e-12)

    best_val_loss, epochs_without_improvement, history = np.inf, 0, []
    best_path = osp.join(args.out_dir, 'checkpoints', 'checkpoint_best.pt')

    try:
        for epoch in range(args.epochs):
            epoch_t = time.time()
            network.train()
            running_loss, n_batches = 0.0, 0
            for feat, targ, _, _ in train_loader:
                feat, targ = feat.to(device), targ.to(device)
                optimizer.zero_grad()
                loss = criterion(network(feat), targ)
                loss.backward()
                optimizer.step()
                running_loss += loss.item()
                n_batches += 1
            train_loss = running_loss / max(n_batches, 1)

            val_targets, val_preds = run_inference(network, val_loader, device)
            val_loss = float(np.mean((val_targets - val_preds) ** 2))
            scheduler.step(val_loss)

            improved = val_loss < best_val_loss
            if improved:
                best_val_loss, epochs_without_improvement = val_loss, 0
                torch.save({'model_state_dict': network.state_dict(),
                            'optimizer_state_dict': optimizer.state_dict(),
                            'epoch': epoch}, best_path)
            else:
                epochs_without_improvement += 1

            history.append({'epoch': epoch, 'train_loss': train_loss, 'val_loss': val_loss})
            print('Epoch {:3d}/{}  {:.1f}s  train loss {:.6f}  val loss {:.6f}  lr {:.2e}{}'.format(
                epoch + 1, args.epochs, time.time() - epoch_t, train_loss, val_loss,
                optimizer.param_groups[0]['lr'], '  *best*' if improved else ''), flush=True)
            with open(osp.join(args.out_dir, 'history.json'), 'w') as f:
                json.dump(history, f, indent=2)

            if epochs_without_improvement >= args.early_stop:
                print('No validation improvement for {} epochs, stopping early.'.format(
                    args.early_stop))
                break
    except KeyboardInterrupt:
        print('Early terminate')

    torch.save({'model_state_dict': network.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'epoch': len(history) - 1},
               osp.join(args.out_dir, 'checkpoints', 'checkpoint_latest.pt'))
    print('Training complete. Best validation loss: {:.6f}'.format(best_val_loss))

    print('\nEvaluating the best checkpoint on the test set:')
    network.load_state_dict(torch.load(best_path, map_location=device)['model_state_dict'])
    evaluate(network, args, test_list, device)


def main():
    parser = argparse.ArgumentParser(
        description='Train RoNIN ResNet18 from scratch on the IMUNet dataset.')
    default_root = osp.join(_REPO_ROOT, 'Datasets', 'IMUNet_dataset')
    parser.add_argument('--root_dir', type=str, default=default_root)
    parser.add_argument('--train_list', type=str, default=None,
                        help='default: <root_dir>/list_train.txt')
    parser.add_argument('--test_list', type=str, default=None,
                        help='default: <root_dir>/list_test.txt')
    parser.add_argument('--val_ratio', type=float, default=0.12,
                        help='fraction of the training sequences held out for validation')
    parser.add_argument('--out_dir', type=str, default='Train_out/ResNet/imunet_scratch')
    parser.add_argument('--cache_path', type=str, default=None,
                        help='optional hdf5 cache of the compiled sequences')
    parser.add_argument('--lr', type=float, default=1e-4)
    parser.add_argument('--lr_patience', type=int, default=6)
    parser.add_argument('--batch_size', type=int, default=128)
    parser.add_argument('--epochs', type=int, default=100)
    parser.add_argument('--early_stop', type=int, default=15,
                        help='stop after this many epochs without a validation improvement')
    parser.add_argument('--step_size', type=int, default=10)
    parser.add_argument('--window_size', type=int, default=200)
    parser.add_argument('--max_ori_error', type=float, default=20.0)
    parser.add_argument('--workers', type=int, default=0)
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--cpu', action='store_true')
    args = parser.parse_args()

    if args.train_list is None:
        args.train_list = osp.join(args.root_dir, 'list_train.txt')
    if args.test_list is None:
        args.test_list = osp.join(args.root_dir, 'list_test.txt')

    train(args)


if __name__ == '__main__':
    main()
