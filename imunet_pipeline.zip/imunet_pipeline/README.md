# Pipeline IMUNet — pacote para servidor

Valida, treina e exporta para ExecuTorch (`.pte`) um modelo de odometria inercial no formato
de dados do IMUNet. Autocontido: **não** dependa de clonar o repositório original do IMUNet
no servidor, porque o `utils.py` e o `model_resnet1d.py` publicados lá não importam em
ambiente atual — pedem `numba`, `scipy.ndimage.filters` (removido no SciPy moderno) e
`pthflops`. As cópias deste pacote já estão corrigidas.

## Conteúdo

| arquivo | o que é |
|---|---|
| `validate_dataset.py` | checagem de referencial e integridade do dataset (é o que você quer rodar primeiro) |
| `train_proposed.py` | treino da ResNet18 1D do zero |
| `export_pte.py` | exporta um checkpoint para `.pte` (ExecuTorch/XNNPACK) |
| `utils.py`, `model_resnet1d.py`, `metric.py` | dependências, corrigidas para rodar |

## Instalação

```bash
python -m venv .venv
.venv/bin/pip install -r requirements.txt
```

Leia os comentários do `requirements.txt`: o `torch` do treino e o do `executorch` são
incompatíveis e precisam de virtualenvs separados. Para só validar o dataset, `torch` de CPU
resolve.

## Layout de dados esperado

```
<root_dir>/
  list_train.txt          # um nome de sequência por linha
  list_test.txt
  <nome_da_sequencia>/
    processed/data.csv    # ou data.pkl
```

O CSV precisa das colunas `time` (nanossegundos), `gyro_x/y/z` (rad/s), `acce_x/y/z` (m/s²,
**com** gravidade), `pos_x/y/z`, `ori_w/x/y/z` e `rv_w/x/y/z`. Quaternions em ordem
`(w,x,y,z)` — o Android entrega `(x,y,z,w)`, e trocar a ordem não gera erro nenhum, só um
referencial silenciosamente errado. O `validate_dataset.py` detecta isso.

## 1. Validar

```bash
cd imunet_pipeline
python validate_dataset.py --root_dir /caminho/do/dataset
python validate_dataset.py --root_dir /caminho/do/dataset --list /caminho/list_train.txt
```

Sai com código ≠ 0 se qualquer sequência falhar, então serve de gate antes do treino.
Use `--verbose` para ver os números dos checks que passaram (margem antes de virar falha).

Os checks, e o que uma falha significa:

| check | falha quer dizer |
|---|---|
| `columns` | falta coluna ou tem NaN |
| `rate` | timestamps não crescentes, ou buraco > 0.5 s, ou > 2% da gravação perdida |
| `quat` | quaternion não normalizado, ou em ordem `(x,y,z,w)` |
| `rv_frame` | o rotation vector do dispositivo não é alinhado à gravidade, ou o acelerômetro está descalibrado em amplitude |
| `tilt` | o referencial global que o pipeline entrega à rede não tem a gravidade em +z |
| `stable` | a direção da gravidade passeia ao longo da gravação (orientação derivando ou resetando) |
| `vertical` | o trajeto do ground truth se move demais ao longo do eixo da gravidade |
| `recon` | integrar os alvos não reproduz as posições: rótulos e trajetória não batem |

A combinação diagnóstica que importa: **`rv_frame` passando e `tilt` falhando** significa que
a IMU e a orientação do celular estão certas e o erro está na composição com o ground truth
(`init_rotor` / colunas `ori_*` em `utils.py:473`). Foi exatamente esse o caso em 77 das 129
sequências do dataset IMUNet original.

Limiares ajustáveis: `--max_tilt_deg` (5), `--max_vertical_ratio` (0.2, afrouxe se o dataset
tiver escada ou rampa), `--max_drift_deg` (10), `--max_gap_s` (0.5), `--max_gap_fraction`
(0.02), `--max_recon_error` (0.5 m), `--expected_rate` (200 Hz).

## 2. Treinar

```bash
python train_proposed.py --root_dir /caminho/do/dataset --out_dir Train_out/run1 --epochs 100
```

Separa validação por sequência inteira a partir do `list_train.txt` (`--val_ratio`, padrão
0.12, semente 42), deixando o `list_test.txt` só para a avaliação final. Salva
`checkpoints/checkpoint_best.pt`, `config.json` (com os splits resolvidos), `history.json` e,
ao final, `metrics_test.csv` com MSE, ATE e RTE por sequência.

Referência de custo: 79 sequências de treino ≈ 413 mil janelas, ~81 s por época numa RTX 2080
Super. Redirecione a saída para um arquivo, é verbosa.

## 3. Exportar

Em um virtualenv **separado**, com `executorch`:

```bash
python export_pte.py --checkpoint Train_out/run1/checkpoints/checkpoint_best.pt \
                     --output modelo.pte
```

Verifica o `.pte` contra o eager mode e falha se divergirem além de `--tolerance` (1e-4).
`--no_xnnpack` gera um programa portátil sem o delegate de CPU.

## Restrições fixas

Taxa de 200 Hz e janela de 200 amostras (1 s) estão embutidas: o `in_dim` da cabeça FC é
`window_size // 32 + 1` e o RTE usa `200 * 60`. Dataset em outra taxa precisa ser reamostrado
para 200 Hz, ou treinado com `--window_size` coerente e reexportado.

Entrada do modelo: `(1, 6, 200)` float32 — giroscópio e acelerômetro **já rotacionados para o
referencial global alinhado à gravidade**. Saída: `(1, 2)`, velocidade 2D em m/s no mesmo
referencial. O yaw absoluto desse referencial é irrelevante (o treino sorteia yaw de 0 a 360°),
então na inferência basta o rotation vector do próprio aparelho: a trajetória sai correta a
menos de uma rotação constante em torno da vertical.
