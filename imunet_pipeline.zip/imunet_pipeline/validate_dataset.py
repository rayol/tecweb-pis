"""
Check that a dataset is in the reference frame the training pipeline assumes.

The network learns a mapping from global-frame IMU to global-frame velocity, so the features
and the targets have to live in one and the same world frame, and that frame has to be
gravity-aligned with z up -- RandomHoriRotate (utils.py:28) augments yaw around z only, which
is the right symmetry group for the data exactly when z is the vertical axis.

Nothing in the pipeline verifies this. A dataset whose IMU frame and position frame disagree
loads, trains and produces plausible-looking losses; the mistake only shows up as accuracy
that never quite gets there. The IMUNet dataset itself gets it wrong for every non-Tango
sequence, which is what motivated this script.

The checks, per sequence:

  columns    the CSV has every field ProposedSequence reads, without NaNs
  rate       timestamps are monotonic and at the expected sampling rate, and dropouts stay
             short enough that a window never spans a meaningful hole in the timeline
  quat       the rotation-vector column is normalised, and is in (w,x,y,z) order rather
             than the (x,y,z,w) order Android hands out -- swapping those raises no error,
             it just silently yields a wrong frame
  rv_frame   rotating the raw accelerometer by the rotation vector alone puts gravity on
             +z, i.e. the fused orientation really is gravity-aligned. This is independent
             of the tracker, so it separates "the rv column is wrong" from "the tracker
             alignment is wrong"
  tilt       same test on the frame the pipeline actually builds (rv composed with the
             initial tracker orientation). rv_frame passing while tilt fails means the
             fault is in init_rotor / the ori_* columns, not in the IMU
  stable     the gravity direction stays put over the recording, catching an orientation
             source that drifts or resets. Note this constrains roll and pitch only --
             a slow yaw drift is not observable from the data alone
  vertical   the ground-truth trajectory barely moves along the gravity axis, as walking on
             a flat floor must. Raise --max_vertical_ratio for datasets with stairs or ramps
  recon      integrating the targets reproduces the ground-truth positions, so the velocity
             labels really do belong to the trajectory they are paired with

Usage (from the directory holding this file):
    python validate_dataset.py
    python validate_dataset.py --root_dir <dir> --list <file.txt>

Exits non-zero if any sequence fails, so it can gate a training run.
"""
import argparse
import io
import os
import os.path as osp
import sys
from contextlib import redirect_stdout

import numpy as np
import pandas
import quaternion

from utils import ProposedSequence

_REPO_ROOT = osp.dirname(osp.dirname(osp.abspath(__file__)))
_GRAVITY = 9.81

_REQUIRED_COLUMNS = (['time'] +
                     ['gyro_' + a for a in 'xyz'] + ['acce_' + a for a in 'xyz'] +
                     ['pos_' + a for a in 'xyz'] +
                     ['ori_' + a for a in 'wxyz'] + ['rv_' + a for a in 'wxyz'])


def read_raw(seq_dir):
    csv_path = osp.join(seq_dir, 'processed', 'data.csv')
    if osp.exists(csv_path):
        return pandas.read_csv(csv_path)
    return pandas.read_pickle(osp.join(seq_dir, 'processed', 'data.pkl'))


def rotate(quats, vectors):
    """Rotate device-frame vectors into the world frame: q * v * q.conj()."""
    padded = quaternion.from_float_array(
        np.concatenate([np.zeros((vectors.shape[0], 1)), vectors], axis=1))
    return quaternion.as_float_array(quats * padded * quats.conj())[:, 1:]


def tilt_deg(vec):
    """Angle between a vector and +z, in degrees."""
    norm = np.linalg.norm(vec)
    if norm < 1e-9:
        return float('nan')
    return float(np.degrees(np.arccos(np.clip(vec[2] / norm, -1.0, 1.0))))


def check_columns(raw):
    missing = [c for c in _REQUIRED_COLUMNS if c not in raw.columns]
    if missing:
        return False, 'faltam colunas: {}'.format(', '.join(missing))
    nan_columns = [c for c in _REQUIRED_COLUMNS if raw[c].isna().any()]
    if nan_columns:
        return False, 'NaN em: {}'.format(', '.join(nan_columns))
    return True, '{} amostras'.format(len(raw))


def check_rate(raw, args):
    """Sampling rate, plus how much of the recording is lost to dropouts.

    Windows are cut as contiguous index slices, so a gap makes a window silently span a
    discontinuity in time. Occasional dropped samples are harmless and normal in phone
    recordings; what matters is a single long gap, or losing a large share of the timeline.
    """
    ts = raw['time'].values / 1e09
    dts = np.diff(ts)
    if np.any(dts <= 0):
        return False, float('nan'), '{} timestamps nao crescentes'.format(int(np.sum(dts <= 0)))

    median_dt = float(np.median(dts))
    rate = 1.0 / median_dt
    gaps = dts[dts > 5 * median_dt]
    max_gap = float(gaps.max()) if len(gaps) else 0.0
    lost_fraction = float(gaps.sum() / (ts[-1] - ts[0])) if len(gaps) else 0.0

    detail = '{:.1f} Hz'.format(rate)
    if len(gaps):
        detail += ', maior gap {:.3f}s, {:.1f}% perdido'.format(max_gap, 100 * lost_fraction)
    ok = (abs(rate - args.expected_rate) <= args.rate_tolerance * args.expected_rate
          and max_gap <= args.max_gap_s and lost_fraction <= args.max_gap_fraction)
    return ok, rate, detail


def check_quaternion(raw):
    """Normalisation, plus which column order puts gravity on +z."""
    wxyz = raw[['rv_w', 'rv_x', 'rv_y', 'rv_z']].values
    norms = np.linalg.norm(wxyz, axis=1)
    if not np.allclose(norms, 1.0, atol=1e-2):
        return False, 'norma media {:.3f}, esperado 1.0'.format(float(norms.mean()))

    acce = raw[['acce_x', 'acce_y', 'acce_z']].values
    tilts = {}
    for label, columns in (('wxyz', ['rv_w', 'rv_x', 'rv_y', 'rv_z']),
                           ('xyzw', ['rv_x', 'rv_y', 'rv_z', 'rv_w'])):
        quats = quaternion.from_float_array(raw[columns].values)
        tilts[label] = tilt_deg(rotate(quats, acce).mean(axis=0))

    if tilts['xyzw'] + 10.0 < tilts['wxyz']:
        return False, 'ordem parece (x,y,z,w): tilt {:.1f} vs {:.1f} em (w,x,y,z)'.format(
            tilts['xyzw'], tilts['wxyz'])
    return True, 'ordem (w,x,y,z), norma 1.0'


def check_rv_frame(raw, max_tilt):
    """Gravity in the frame of the fused orientation alone -- the tracker plays no part."""
    quats = quaternion.from_float_array(raw[['rv_w', 'rv_x', 'rv_y', 'rv_z']].values)
    gravity = rotate(quats, raw[['acce_x', 'acce_y', 'acce_z']].values).mean(axis=0)
    tilt = tilt_deg(gravity)
    magnitude = float(np.linalg.norm(gravity))
    ok = tilt <= max_tilt and abs(magnitude - _GRAVITY) < 1.0
    return ok, tilt, 'tilt {:.1f} deg, |g| {:.2f}'.format(tilt, magnitude)


def check_tilt(features, max_tilt):
    """Same, but on the global frame the pipeline hands to the network."""
    gravity = features[:, 3:].mean(axis=0)
    tilt = tilt_deg(gravity)
    magnitude = float(np.linalg.norm(gravity))
    ok = tilt <= max_tilt and abs(magnitude - _GRAVITY) < 1.0
    return ok, tilt, 'tilt {:.1f} deg, |g| {:.2f}'.format(tilt, magnitude)


def check_stable(features, ts, max_drift, window_s=10.0):
    """How far the gravity direction wanders across the recording."""
    acce = features[:, 3:]
    rate = 1.0 / np.median(np.diff(ts))
    size = max(int(window_s * rate), 1)
    n_windows = len(acce) // size
    if n_windows < 2:
        return True, 0.0, 'sequencia curta demais'

    means = acce[:n_windows * size].reshape(n_windows, size, 3).mean(axis=1)
    means /= np.linalg.norm(means, axis=1, keepdims=True)
    overall = means.mean(axis=0)
    overall /= np.linalg.norm(overall)
    drift = float(np.degrees(np.arccos(np.clip(means @ overall, -1.0, 1.0))).max())
    return drift <= max_drift, drift, 'desvio max {:.1f} deg'.format(drift)


def check_vertical(features, gt_pos, max_ratio):
    """A pedestrian on a flat floor does not move along gravity."""
    gravity = features[:, 3:].mean(axis=0)
    gravity = gravity / np.linalg.norm(gravity)
    centred = gt_pos - gt_pos.mean(axis=0)
    along = centred @ gravity
    perpendicular = centred - np.outer(along, gravity)
    vertical = float(along.std())
    horizontal = float(np.linalg.norm(perpendicular, axis=1).std())
    ratio = vertical / max(horizontal, 1e-9)
    return ratio <= max_ratio, ratio, '{:.2f} m vertical / {:.2f} m horizontal'.format(
        vertical, horizontal)


def check_recon(targets, gt_pos, ts, window_size, tolerance):
    """Integrate the velocity labels and compare against the trajectory they came from.

    The targets are the average velocity over a window, so their integral tracks the
    trajectory smoothed by that window and delayed by half of it; comparing against
    gt_pos shifted by window_size // 2 removes the bulk of that lag.
    """
    n = targets.shape[0]
    dts = np.diff(ts[:n + 1])
    offset = window_size // 2
    reconstructed = np.cumsum(targets * dts[:, None], axis=0) + gt_pos[offset, :2]
    reference = gt_pos[offset:offset + n, :2]
    error = float(np.linalg.norm(reconstructed - reference, axis=1).mean())
    return error <= tolerance, error, 'erro medio {:.3f} m'.format(error)


def validate(seq_dir, args):
    """Run every check on one sequence. Returns (name, list of (check, ok, detail))."""
    name = osp.basename(seq_dir.rstrip('/\\'))
    results = []

    raw = read_raw(seq_dir)
    ok, detail = check_columns(raw)
    results.append(('columns', ok, detail))
    if not ok:
        return name, results

    ok, _, detail = check_rate(raw, args)
    results.append(('rate', ok, detail))

    ok, detail = check_quaternion(raw)
    results.append(('quat', ok, detail))

    ok, _, detail = check_rv_frame(raw, args.max_tilt_deg)
    results.append(('rv_frame', ok, detail))

    # Silence the shape dump ProposedSequence.load prints for every sequence.
    with redirect_stdout(io.StringIO()):
        sequence = ProposedSequence(seq_dir, interval=args.window_size)
    features, targets = sequence.get_feature(), sequence.get_target()
    gt_pos, ts = sequence.gt_pos, sequence.ts.ravel()

    ok, _, detail = check_tilt(features, args.max_tilt_deg)
    results.append(('tilt', ok, detail))

    ok, _, detail = check_stable(features, ts, args.max_drift_deg)
    results.append(('stable', ok, detail))

    ok, _, detail = check_vertical(features, gt_pos, args.max_vertical_ratio)
    results.append(('vertical', ok, detail))

    ok, _, detail = check_recon(targets, gt_pos, ts, args.window_size, args.max_recon_error)
    results.append(('recon', ok, detail))

    return name, results


def main():
    parser = argparse.ArgumentParser(
        description='Validate the reference frame of a dataset before training on it.')
    parser.add_argument('--root_dir', type=str,
                        default=osp.join(_REPO_ROOT, 'Datasets', 'IMUNet_dataset'))
    parser.add_argument('--list', type=str, default=None,
                        help='sequence list file (default: every subdirectory of root_dir)')
    parser.add_argument('--window_size', type=int, default=200,
                        help='must match the training window: it sets the target interval')
    parser.add_argument('--expected_rate', type=float, default=200.0, help='Hz')
    parser.add_argument('--rate_tolerance', type=float, default=0.05,
                        help='accepted relative deviation from expected_rate')
    parser.add_argument('--max_gap_s', type=float, default=0.5,
                        help='longest tolerated hole in the timeline, in seconds')
    parser.add_argument('--max_gap_fraction', type=float, default=0.02,
                        help='max share of the recording lost to dropouts')
    parser.add_argument('--max_tilt_deg', type=float, default=5.0,
                        help='max angle between the global gravity and +z')
    parser.add_argument('--max_drift_deg', type=float, default=10.0,
                        help='max wander of the gravity direction across the recording')
    parser.add_argument('--max_vertical_ratio', type=float, default=0.2,
                        help='max vertical/horizontal spread of the trajectory')
    parser.add_argument('--max_recon_error', type=float, default=0.5,
                        help='max mean error, in metres, of the integrated targets')
    parser.add_argument('--verbose', action='store_true',
                        help='print every check, not just the failing ones')
    args = parser.parse_args()

    if args.list:
        with open(args.list) as f:
            names = [s.strip().split(',')[0] for s in f if s.strip() and s[0] != '#']
    else:
        names = sorted(d for d in os.listdir(args.root_dir)
                       if osp.isdir(osp.join(args.root_dir, d)))
    if not names:
        raise SystemExit('No sequences found in {}'.format(args.root_dir))

    check_names = ['columns', 'rate', 'quat', 'rv_frame', 'tilt', 'stable', 'vertical', 'recon']
    print('{:<34}{}'.format('sequencia', '  '.join('{:<9}'.format(c) for c in check_names)))
    print('-' * 34 + '-' * (11 * len(check_names)))

    failures, failed_counts = [], {c: 0 for c in check_names}
    for name in names:
        seq_name, results = validate(osp.join(args.root_dir, name), args)
        status = {check: ok for check, ok, _ in results}
        cells = []
        for check in check_names:
            if check not in status:
                cells.append('{:<9}'.format('-'))
            else:
                cells.append('{:<9}'.format('OK' if status[check] else 'FALHA'))
        print('{:<34}{}'.format(seq_name[:33], '  '.join(cells)), flush=True)

        for check, ok, detail in results:
            if not ok:
                failed_counts[check] += 1
                failures.append((seq_name, check, detail))
            if args.verbose and ok:
                print('    {:<10} {}'.format(check, detail))

    print()
    if not failures:
        print('Todas as {} sequencias passaram.'.format(len(names)))
        return

    print('{} sequencia(s) com problema, {} falha(s) no total:'.format(
        len({f[0] for f in failures}), len(failures)))
    for check in check_names:
        if failed_counts[check]:
            print('  {:<10} {} sequencia(s)'.format(check, failed_counts[check]))
    print()
    for seq_name, check, detail in failures:
        print('  {:<34} {:<10} {}'.format(seq_name[:33], check, detail))
    sys.exit(1)


if __name__ == '__main__':
    main()
