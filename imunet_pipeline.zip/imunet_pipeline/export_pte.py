"""
Export a fine-tuned RoNIN ResNet18 checkpoint to an ExecuTorch .pte program.

The network is the same ResNet1D used by finetune_imunet.py: 6 input channels (global-frame
gyroscope + accelerometer), a window of `--window_size` samples, and 2 outputs (global 2D
velocity in m/s). The checkpoint is loaded with strict=True, so a mismatch between the saved
weights and the architecture built here is an error rather than a silently random layer.

The model is exported in eval mode, which folds the BatchNorm statistics into inference
behaviour and turns the two Dropout layers into identities, then lowered to the XNNPACK
backend (the CPU delegate used on Android/iOS/desktop). Pass --no_xnnpack to emit a portable
program that runs on the reference kernels only.

Usage:
    ../.venv-et/Scripts/python.exe export_pte.py
    ../.venv-et/Scripts/python.exe export_pte.py --checkpoint <path> --output <path.pte>

Note this needs the export virtualenv (.venv-et, torch 2.13 + executorch), not the training
one (.venv, torch 2.7.1+cu126) -- executorch pins its own torch version.
"""
import argparse
import os
import os.path as osp
import sys


def _locate_flatc():
    """Point executorch at flatc.exe.

    executorch 1.4.1 looks for a resource literally named `flatc` inside `executorch.data.bin`.
    On Windows the packaged binary is `flatc.exe`, so the lookup misses and falls back to a
    bare `flatc` on PATH -- which is only there when the virtualenv has been activated.
    Setting FLATC_EXECUTABLE to the absolute path makes the export work however python was
    invoked. Harmless on platforms where the resource lookup already succeeds.
    """
    if os.getenv('FLATC_EXECUTABLE'):
        return
    for candidate in (osp.join(sys.prefix, 'Lib', 'site-packages', 'executorch', 'data', 'bin', 'flatc.exe'),
                      osp.join(sys.prefix, 'Scripts', 'flatc.exe')):
        if osp.isfile(candidate):
            os.environ['FLATC_EXECUTABLE'] = candidate
            return


_locate_flatc()

import torch
from executorch.exir import to_edge_transform_and_lower
from executorch.backends.xnnpack.partition.xnnpack_partitioner import XnnpackPartitioner

from model_resnet1d import ResNet1D, BasicBlock1D, FCOutputModule

# Kept identical to finetune_imunet.py.
_fc_config = {'fc_dim': 512, 'in_dim': 7, 'dropout': 0.5, 'trans_planes': 128}
_input_channel, _output_channel = 6, 2

_DEFAULT_CHECKPOINT = 'Train_out/ResNet/imunet_finetune_lr3e-5/checkpoints/checkpoint_best.pt'


def build_network(window_size):
    fc_config = dict(_fc_config)
    fc_config['in_dim'] = window_size // 32 + 1
    return ResNet1D(_input_channel, _output_channel, BasicBlock1D, [2, 2, 2, 2],
                    base_plane=64, output_block=FCOutputModule, kernel_size=3, **fc_config)


def load_checkpoint(network, path):
    checkpoint = torch.load(path, map_location='cpu', weights_only=False)
    state_dict = checkpoint.get('model_state_dict', checkpoint)
    network.load_state_dict(state_dict, strict=True)
    print('Loaded {} tensors from {} (epoch {})'.format(
        len(state_dict), path, checkpoint.get('epoch', '?')))
    return network


def export(args):
    network = build_network(args.window_size)
    load_checkpoint(network, args.checkpoint)
    network.eval()

    example_inputs = (torch.randn(args.batch_size, _input_channel, args.window_size),)
    with torch.no_grad():
        reference = network(*example_inputs)
    print('Model: {} parameters, input {} -> output {}'.format(
        sum(p.numel() for p in network.parameters()),
        tuple(example_inputs[0].shape), tuple(reference.shape)))

    exported = torch.export.export(network, example_inputs)
    partitioners = [] if args.no_xnnpack else [XnnpackPartitioner()]
    edge = to_edge_transform_and_lower(exported, partitioner=partitioners)
    program = edge.to_executorch()

    os.makedirs(osp.dirname(osp.abspath(args.output)), exist_ok=True)
    with open(args.output, 'wb') as f:
        f.write(program.buffer)
    print('Wrote {} ({:.2f} MiB, backend: {})'.format(
        args.output, osp.getsize(args.output) / 1024 ** 2,
        'portable' if args.no_xnnpack else 'XNNPACK'))

    return example_inputs, reference


def verify(args, example_inputs, reference):
    """Run the .pte through the ExecuTorch runtime and compare against the eager output."""
    from executorch.runtime import Runtime

    method = Runtime.get().load_program(args.output).load_method('forward')
    actual = method.execute(list(example_inputs))[0]

    error = (actual - reference).abs().max().item()
    print('Runtime check: eager {} vs .pte {}, max |diff| = {:.3e}'.format(
        reference.flatten().tolist(), actual.flatten().tolist(), error))
    if error > args.tolerance:
        raise SystemExit('FAILED: max difference {:.3e} exceeds tolerance {:.3e}'.format(
            error, args.tolerance))
    print('OK: outputs agree within {:.3e}'.format(args.tolerance))


def main():
    parser = argparse.ArgumentParser(
        description='Export a fine-tuned RoNIN ResNet checkpoint to ExecuTorch (.pte).')
    parser.add_argument('--checkpoint', type=str, default=_DEFAULT_CHECKPOINT,
                        help='fine-tuned checkpoint to export (default: the lr 3e-5 best)')
    parser.add_argument('--output', type=str, default=None,
                        help='destination .pte (default: <checkpoint dir>/../model.pte)')
    parser.add_argument('--window_size', type=int, default=200)
    parser.add_argument('--batch_size', type=int, default=1,
                        help='fixed batch size baked into the program')
    parser.add_argument('--no_xnnpack', action='store_true',
                        help='skip XNNPACK lowering and emit a portable-kernel program')
    parser.add_argument('--no_verify', action='store_true',
                        help='skip running the exported program through the runtime')
    parser.add_argument('--tolerance', type=float, default=1e-4)
    args = parser.parse_args()

    if args.output is None:
        args.output = osp.join(osp.dirname(osp.dirname(osp.abspath(args.checkpoint))), 'model.pte')

    example_inputs, reference = export(args)
    if not args.no_verify:
        verify(args, example_inputs, reference)


if __name__ == '__main__':
    main()
